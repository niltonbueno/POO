﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float nota1, nota2, nota3, nota4, nota5, nota6, promedio;
            string numero;

            Console.Write("ingrese nota 1: ");
            numero = Console.ReadLine();
            nota1 = float.Parse(numero);

            Console.Write("ingrese nota 2: ");
            numero = Console.ReadLine();
            nota2 = float.Parse(numero);

            Console.Write("ingrese nota 3: ");
            numero = Console.ReadLine();
            nota3 = float.Parse(numero);

            Console.Write("ingrese nota 4: ");
            numero = Console.ReadLine();
            nota4 = float.Parse(numero);

            Console.Write("ingrese nota 5: ");
            numero = Console.ReadLine();
            nota5 = float.Parse(numero);

            Console.Write("ingrese nota 6: ");
            numero = Console.ReadLine();
            nota6 = float.Parse(numero);



            promedio = (nota1 + nota2 + nota3 + nota4 + nota5 + nota6) / 6;

            if (promedio >= 7) 
            {
                Console.Write("promocionado, su nota es: ");
                Console.WriteLine(promedio);
            }

            Console.ReadKey();
        }
    }
}
