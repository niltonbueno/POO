﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1;
            string numero;

            Console.Write("ingrese un numero: ");
            numero = Console.ReadLine();
            num1 = int.Parse(numero);

            if (num1 >= 1 && num1 <= 9)
            {
                Console.Write("este numero tiene 1 digito");
            }
            else
            {
                if (num1 >= 10 && num1 <= 99)
                {
                    Console.Write("este numero tiene 2 digitos");
                }
            }





            Console.ReadKey();


        }
    }
}
