﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //1. Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo informar su suma y
            //diferencia, en caso contrario informar el producto y la división del primero respecto al segundo.

            float num1, num2, suma, diferencia, producto, division;
            string numero;

            Console.Write("escriba un numero: ");
            numero = Console.ReadLine();
            num1 = float.Parse(numero);

            Console.Write("escriba un numero2: ");
            numero = Console.ReadLine();
            num2 = float.Parse(numero);


            if (num1 > num2) {

                suma = num1 + num2;
                diferencia = num1 - num2;


                Console.Write("la suma es: ");
                Console.WriteLine(suma);


                Console.Write("la diferencia es: ");
                Console.WriteLine(diferencia);

            }
            else
            {
                producto = num1 * num2;
                division = num1 / num2;


                Console.Write("el producto es: ");
                Console.WriteLine(producto);

                Console.Write("la divicion es: ");
                Console.WriteLine(division);

            }


            Console.ReadKey();



        }
    }
}
