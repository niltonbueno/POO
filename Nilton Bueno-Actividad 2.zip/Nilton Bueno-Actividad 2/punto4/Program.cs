﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float num1, num2, num3;
            string numero;

            Console.Write("ingrese un numero: ");
            numero = Console.ReadLine();
            num1 = int.Parse(numero);
            
            Console.Write("ingrese un numero: ");
            numero = Console.ReadLine();
            num2 = int.Parse(numero);

            Console.Write("ingrese un numero: ");
            numero = Console.ReadLine();
            num3 = int.Parse(numero);

            if (num1 > num2 && num1 > num3)
            {
                Console.Write("El primer numero es el mayor");
            }
            else
            {
                if (num2 > num1 && num2 > num3)
                {
                    Console.Write("El segundo numero es el mayor");
                }
                else
                {
                    Console.Write("el tercer numero es el mayor");
                }
            }


            Console.ReadKey();


        }
    }
}
