﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {


           // 2.Escribir un programa en el cual se ingresen cuatro números,
           // calcular e informar la suma de los dos primeros y el producto del tercero y el cuarto.






            int num1, num2, num3, num4, suma, producto;
            string numero;

            Console.WriteLine("escribe un numero: ");
            numero = Console.ReadLine();
            num1 = int.Parse(numero);

            Console.WriteLine("escribe un numero2: ");
            numero = Console.ReadLine();
            num2 = int.Parse(numero);

            Console.WriteLine("escribe un numero3: ");
            numero = Console.ReadLine();
            num3 = int.Parse(numero);

            Console.WriteLine("escribe un numero4: ");
            numero = Console.ReadLine();
            num4 = int.Parse(numero);


            suma = num1 + num2;

            producto = num3 * num4;


            Console.Write("la suma total seria: ");
            Console.WriteLine(suma);

            Console.Write("el producto total seria: ");
            Console.WriteLine(producto);

        }
    }
}
