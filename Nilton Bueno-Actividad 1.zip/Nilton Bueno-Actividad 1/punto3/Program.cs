﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  3.Realizar un programa que lea cuatro valores numéricos e informar su suma y promedio.



            int num1, num2, num3, num4, suma, promedio;
            string numero;

            Console.Write("escribir un numero1: ");
            numero = Console.ReadLine();
            num1 = int.Parse(numero);

            Console.Write("escribir un numero2: ");
            numero = Console.ReadLine();
            num2 = int.Parse(numero);

            Console.Write("escribir un numero3: ");
            numero = Console.ReadLine();
            num3 = int.Parse(numero);

            Console.Write("escribir un numero4: ");
            numero = Console.ReadLine();
            num4 = int.Parse(numero);


            suma = num1 + num2 + num3 + num4;

            promedio = suma / 4;

            Console.Write ("la suma de los 4 es: ");
            Console.WriteLine (suma);

            Console.Write("El promedio es: ");
            Console.WriteLine(promedio);

            Console.ReadKey();

        }
    }
}
