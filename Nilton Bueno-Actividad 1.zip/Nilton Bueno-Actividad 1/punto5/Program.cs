﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace punto5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 5.Realizar la carga del radio de un círculo, mostrar por pantalla la circunferencia y
            // el área del mismo(La circunferencia se calcula multiplicando el doble del radio por π (pi), y el área se calcula multiplicando π por el cuadrado del radio).

            
            
            double num1, circunferencia, radio, inicial;
            string numero;
            
            
            Console.Write("poner el radio: ");
            numero = Console.ReadLine();
            num1 = int.Parse(numero);

                inicial = num1 * 2;
                circunferencia = inicial * Math.PI;

                radio = num1 * num1 * Math.PI;

            Console.Write("la circunferencia total es: ");
            Console.WriteLine(circunferencia);

            Console.Write("el raido total es: ");
            Console.WriteLine(radio);

            Console.ReadKey();

        }
    }
}
