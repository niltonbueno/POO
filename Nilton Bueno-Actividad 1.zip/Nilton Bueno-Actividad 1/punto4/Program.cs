﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
           // 4.Se debe desarrollar un programa que pida el ingreso del precio de un artículo y la
           // cantidad que lleva el cliente. Mostrar lo que debe abonar el comprador.



            int num1, num2, abonar;
            string numero;

            Console.Write("poner el precio: ");
            numero = Console.ReadLine();
            num1 = int.Parse(numero);

            Console.Write("poner la cantidad del producto: ");
            numero = Console.ReadLine();
            num2 = int.Parse(numero);

            abonar = num1 * num2;

            Console.Write("el total a abonar es: ");
            Console.WriteLine(abonar);





        }
    }
}
