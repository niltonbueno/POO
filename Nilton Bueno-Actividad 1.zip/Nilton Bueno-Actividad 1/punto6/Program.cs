﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //6. Escribir un programa que lea el peso (en kilogramos) y la altura (en metros) de una persona, y mostrar
            //por pantalla su índice de masa corporal (IMC) (El IMC se calcula dividiendo el peso entre el cuadrado de la altura).






            double num1, num2, peso;
            string numero;

            Console.Write("poner el peso es: ");
            numero = Console.ReadLine();
            num1 = float.Parse(numero);

            Console.Write("poner la altura es: ");
            numero = Console.ReadLine();
            num2 = float.Parse(numero);


            peso = num1 / (num2 * num2);

            Console.Write("el indice corporal es: ");
            Console.WriteLine(peso);


        }
    }
}
