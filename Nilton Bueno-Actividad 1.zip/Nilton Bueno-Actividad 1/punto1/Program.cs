﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
           // 1.Realizar la carga del lado de un cuadrado, mostrar por pantalla el perímetro del mismo
           // (El perímetro de un cuadrado se calcula multiplicando el valor del lado por cuatro).





            int num1, perimetro;
            string numero;

            Console.Write("coloca un numero aqui: ");
            numero = Console.ReadLine();
            num1 = int.Parse(numero);

            perimetro = num1 * 4;

            Console.Write("el perimetro total es: ");
            Console.WriteLine(perimetro);

            Console.ReadKey();


        }
    }
}
